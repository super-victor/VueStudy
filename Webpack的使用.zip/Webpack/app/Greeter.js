module.exports = function () {
    var greet = document.createElement('p');
    greet.textContent = "Hello Webpack!";
    return greet;
}