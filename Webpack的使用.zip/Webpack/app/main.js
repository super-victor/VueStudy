const greeter = require('./Greeter.js');
document.getElementById('root').appendChild(greeter());