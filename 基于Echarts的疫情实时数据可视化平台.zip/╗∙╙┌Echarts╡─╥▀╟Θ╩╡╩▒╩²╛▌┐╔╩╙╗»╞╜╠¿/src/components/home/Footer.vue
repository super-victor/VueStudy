!<!-- Footer -->
<template>
  <div class='footer'>
    <p class="copyRight">Copyright © 2020 by Bryce. All rights reserved.</p>
  </div>
</template>

<script>
  export default {
    components: {},
    data() {
      return {
        
      };
    },
    computed: {},
    watch: {},
    methods: {
      
    },
    created() {
      
    },
    mounted() {
      
    }
  }
</script>
<style lang='less' scoped>
  .footer{
    height: 100%;
    width: 100%;
    background-color: #1B2033;
    display: flex;
    justify-content: center;
    align-items: center;
    .copyRight{
      height: 40%;
      width: 70%;
      font-size: 0.14rem;
      text-align: center;
      color: white;
    }
  }
</style>